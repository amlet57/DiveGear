<?php include 'header.php'; ?>
    <title>О компании DiveGear Pro</title>
    <meta name="description" content="DiveGear Pro - история и миссия производителя спецодежды для дайвинга. Мы создаем оборудование для дайверов всех уровней.">
    <meta name="keywords" content="о компании, история дайвинг оборудования, производитель дайвинг gear">
    <link rel="canonical" href="https://example.com/about.php">
    <meta property="og:title" content="О компании DiveGear Pro">
    <meta property="og:description" content="История и ценности компании.">
    <h1>О компании</h1>
    <section>
        <h2>Наша история</h2>
        <p>Компания DiveGear Pro разрабатывает и производит передовое снаряжение для дайвинга, которому доверяют дайверы по всему миру — от новичков до исследователей. Мы родились из страсти к подводному миру.
        Основанная более 20 лет назад, наша компания гордится тем, что предлагает одно из лучших и самых надежных снаряжений.</p>
    </section>
    <section>
        <h2>Наша миссия</h2>
        <p>Мы посвящены разработке легкого, комфортного профессионального дайвинг оборудования.</p>
    </section>
    <img src="images/accessories1.jpg" alt="Аксессуары для дайвинга" class="img-fluid">
<?php include 'footer.php'; ?>