<?php include 'header.php'; ?>
    <title>Услуги DiveGear Pro</title>
    <meta name="description" content="Услуги по производству, ремонту и обслуживанию дайвинг оборудования. Кастомизация гидрокостюмов и аксессуаров.">
    <meta name="keywords" content="услуги дайвинг, ремонт оборудования, обслуживание scuba gear">
    <link rel="canonical" href="https://example.com/services.php">
    <meta property="og:title" content="Услуги DiveGear Pro">
    <meta property="og:description" content="Список наших услуг.">
    <h1>Услуги</h1>
    <ul>
        <li>Производство спецодежды и аксессуаров.</li>
        <li>Ремонт и обслуживание scuba gear (регуляторы, BCD, танки).</li>
        <li>Кастомизация оборудования под индивидуальные нужды.</li>
        <li>Инспекция и чистка дайвинг gear.</li>
        <li>Гарантийный сервис на Aqualung, Oceanic и другие бренды.</li>
    </ul>
    
<?php include 'footer.php'; ?>