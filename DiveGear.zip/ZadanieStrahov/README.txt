Тексты:
- О компании: Адаптировано из https://www.divesoft.com/en/about-us (Divesoft), https://www.scuba.com/g/about-us (Scuba.com), https://www.kirbymorgan.com/company/about-us (Kirby Morgan)
- Услуги: Адаптировано из https://www.divers-supply.com/scuba-gear/scuba-gear-service.html (Divers Supply), https://www.force-e.com/dive-shops/service (Force-E), https://www.a1scuba.com/servicing-your-equipment (A-1 Scuba)
- Портфолио: Идеи из https://www.scubadiving.com/best-gear-of-the-year (Scuba Diving), https://scubaonline.de/diving-equipment-professional-shop-with-counselling (Scubaonline)
- Контакты: Структура из https://blog.hubspot.com/service/best-contact-us-pages (HubSpot), https://www.searchenginejournal.com/examples-contact-us-pages/378518 (Search Engine Journal)

Изображения:
- wetsuit1.jpg: https://www.scubadiving.com/sites/default/files/styles/small/public/scubadiving/scu-scubalab-cold-water-wetsuit-opener.jpg?itok=OoO08y4s (Scuba Diving)
- wetsuit2.jpg: https://www.mikesdivestore.com/cdn/shop/articles/Winter_shoot-137.jpg?v=1708610751&width=1600 (Mike's Dive Store)
- wetsuit3.jpg: https://www.scubadiving.com/sites/default/files/styles/655_1x_webp/public/trevor/SeacSpace_Medina_3548_edit.jpg.webp?itok=SwnOiWuq (Scuba Diving, converted to JPG)
- mask1.jpg: https://www.scubadiving.com/sites/default/files/styles/655_1x_webp/public/scuba/images/2022/03/seacitalia50.scubadivingmag.march2022.jpg.webp?itok=upYeyLol (Scuba Diving, converted)
- mask2.jpg: https://www.scubadiving.com/sites/default/files/styles/655_1x_webp/public/trevor/ScubaproGhost_0069_MMedina_edit.jpg.webp?itok=mjU11Vif (Scuba Diving, converted)
- mask3.jpg: https://www.scubadiving.com/sites/default/files/styles/655_1x_webp/public/scuba/images/2022/03/seac_raptor.scubadivingmag.march2022.jpg.webp?itok=lgUQu3jT (Scuba Diving, converted)
- fins1.jpg: https://media.istockphoto.com/id/171358712/photo/scuba-diving-fins-flippers.jpg?s=612x612&w=0&k=20&c=Ojy_O_zBV_snhmcH9lRkWG6NXdz-YOPiYLlX_tklv9Q= (iStock)
- fins2.jpg: https://upload.wikimedia.org/wikipedia/commons/1/1b/SwimFins_01.jpg (Wikimedia)
- fins3.jpg: https://media.istockphoto.com/id/1148990894/photo/scuba-fins-isolated.jpg?s=612x612&w=0&k=20&c=yT5Tofgzv54WemFcjnqm-wFP3_42yPlr-XbWFh77feY= (iStock)
- accessories1.jpg: https://www.scubadiving.com/sites/default/files/styles/hero_image_1200_x_630_/public/hero_images/cavern-gear-spd0817.jpg?itok=04qIcNWX (Scuba Diving)
- accessories2.jpg: https://www.shutterstock.com/image-photo/full-set-scuba-diving-equipment-260nw-1643900578.jpg (Shutterstock)
- accessories3.jpg: https://www.scubadiving.com/sites/default/files/styles/hero_image_1200_x_630_/public/hero_images/scuba-diving-gear-beginner.jpg?itok=nGKapynw (Scuba Diving)

Все изображения использованы для демонстрации; в реальном проекте замените на свои или получите разрешения. 