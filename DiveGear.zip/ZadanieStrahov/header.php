<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="index, follow">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="DiveGear Pro">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f0f8ff; color: #333; }
        .navbar { background-color: #007bff; }
        .navbar-brand, .nav-link { color: white !important; }
    </style>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">DiveGear Pro</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item"><a class="nav-link" href="index.php">Главная</a></li>
                        <li class="nav-item"><a class="nav-link" href="about.php">О компании</a></li>
                        <li class="nav-item"><a class="nav-link" href="services.php">Услуги</a></li>
                        <li class="nav-item"><a class="nav-link" href="portfolio.php">Портфолио</a></li>
                        <li class="nav-item"><a class="nav-link" href="contacts.php">Контакты</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <main class="container mt-4">