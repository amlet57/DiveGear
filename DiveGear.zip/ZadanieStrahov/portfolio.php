<?php include 'header.php'; ?>
    <title>Портфолио DiveGear Pro</title>
    <meta name="description" content="Примеры нашей продукции: гидрокостюмы, маски, ласты и аксессуары для дайвинга.">
    <meta name="keywords" content="портфолио дайвинг gear, примеры scuba equipment">
    <link rel="canonical" href="https://example.com/portfolio.php">
    <meta property="og:title" content="Портфолио DiveGear Pro">
    <meta property="og:description" content="Наши продукты в действии.">
    <h1>Портфолио</h1>
    <div class="row">
        <div class="col-md-3">
            <img src="images/wetsuit3.jpg" alt="Гидрокостюм модель 1" class="img-fluid">
            <h3>Гидрокостюм ProWarm</h3>
        </div>
        <div class="col-md-3">
            <img src="images/mask3.jpg" alt="Маска ClearView" class="img-fluid">
            <h3>Маска ClearView</h3>
        </div>
        <div class="col-md-3">
            <img src="images/fins2.jpg" alt="Ласты SpeedFin" class="img-fluid">
            <h3>Ласты SpeedFin</h3>
        </div>
        <div class="col-md-3">
            <img src="images/accessories2.jpg" alt="Аксессуары Kit" class="img-fluid">
            <h3>Комплект аксессуаров</h3>
        </div>
    </div>
<?php include 'footer.php'; ?>