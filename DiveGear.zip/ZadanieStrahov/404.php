<?php include 'header.php'; ?>
    <title>Страница не найдена - DiveGear Pro</title>
    <meta name="description" content="Ошибка 404: Страница не найдена. Вернитесь на главную DiveGear Pro.">
    <meta name="keywords" content="404 ошибка, страница не найдена">
    <link rel="canonical" href="https://example.com/404.php">
    <meta property="og:title" content="404 - DiveGear Pro">
    <meta property="og:description" content="Страница не найдена.">
    <h1>Ошибка 404: Страница не найдена</h1>
    <p>Извините, запрашиваемая страница не существует. Вернитесь на <a href="index.php">главную</a>.</p>
    <img src="images/accessories3.jpg" alt="Изображение для 404 страницы" class="img-fluid">
<?php include 'footer.php'; ?>