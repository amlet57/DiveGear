<?php include 'header.php'; ?>
    <title>DiveGear Pro - Производитель спецодежды и аксессуаров для дайвинга</title>
    <meta name="description" content="DiveGear Pro - ведущий производитель качественной спецодежды и аксессуаров для дайвинга. Надежное оборудование для начинающих и профессионалов.">
    <meta name="keywords" content="дайвинг, спецодежда, аксессуары, гидрокостюмы, маски, ласты">
    <link rel="canonical" href="https://example.com/index.php">
    <meta property="og:title" content="DiveGear Pro - Главная">
    <meta property="og:description" content="Производитель спецодежды для дайвинга.">
    <h1>Добро пожаловать в DiveGear Pro</h1>
    <p>Мы производим высококачественную спецодежду и аксессуары для дайвинга, доверенные дайверам по всему миру.</p>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <img src="images/wetsuit1.jpg" class="card-img-top" alt="Гидрокостюм для дайвинга">
                <div class="card-body">
                    <h2 class="card-title">Гидрокостюмы</h2>
                    <p>Комфортные и теплые костюмы для холодной воды.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="images/mask1.jpg" class="card-img-top" alt="Маска для дайвинга">
                <div class="card-body">
                    <h2 class="card-title">Маски</h2>
                    <p>Четкий обзор под водой.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="images/fins1.jpg" class="card-img-top" alt="Ласты для дайвинга">
                <div class="card-body">
                    <h2 class="card-title">Ласты</h2>
                    <p>Эффективное плавание.</p>
                </div>
            </div>
        </div>
    </div>
<?php include 'footer.php'; ?>