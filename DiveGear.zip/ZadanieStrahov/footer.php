    </main>
    <footer class="bg-light text-center py-3 mt-4">
        <p>&copy; 2026 DiveGear Pro. Все права защищены.</p>
    </footer>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>