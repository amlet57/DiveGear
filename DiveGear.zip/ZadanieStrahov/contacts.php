<?php include 'header.php'; ?>
    <title>Контакты DiveGear Pro</title>
    <meta name="description" content="Свяжитесь с нами для заказа спецодежды и аксессуаров для дайвинга. Адрес, телефон, email и форма обратной связи.">
    <meta name="keywords" content="контакты дайвинг компания, адрес производителя scuba gear">
    <link rel="canonical" href="https://example.com/contacts.php">
    <meta property="og:title" content="Контакты DiveGear Pro">
    <meta property="og:description" content="Как с нами связаться.">
    <h1>Контакты</h1>
    <p>Адрес: ул. Морская, 10, Москва, Россия</p>
    <p>Телефон: +7 (495) 123-45-67</p>
    <p>Email: info@divegearpro.com</p>
    <form class="row g-3">
        <div class="col-md-6">
            <label for="name" class="form-label">Имя</label>
            <input type="text" class="form-control" id="name">
        </div>
        <div class="col-md-6">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email">
        </div>
        <div class="col-12">
            <label for="message" class="form-label">Сообщение</label>
            <textarea class="form-control" id="message" rows="3"></textarea>
        </div>
        <div class="col-12">
            <button type="submit" class="btn btn-primary">Отправить</button>
        </div>
    </form>
<?php include 'footer.php'; ?>